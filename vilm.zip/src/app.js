// document.addEventListener("DOMContentLoaded", main)
import SiteFooter from './script/component/site-footer.js';
import SiteHero from './script/component/site-hero.js';
import NavBar from './script/component/nav-bar.js';
import './style/style.css';
import trendNow from './script/main.js';

trendNow();




